chrome.browserAction.onClicked.addListener(
    function() {
        window.open("./dist/index.html");
    }
);
